# Bienxe > 2025-01-09 7:20am
https://universe.roboflow.com/workspace-wrfuf/bienxe-lzr7i

Provided by a Roboflow user
License: CC BY 4.0

